To run this application
=======================

1. File for a mapbox api token at https://www.mapbox.com (it's free)
2. edit wt_config.xml and add your token
3. open a console to this directory and run with:
	example.exe --docroot . --http-address 0.0.0.0 --http-port 8080 -c wt_config.xml

4. browse through the examples and compare with the demo code if you're not sure what they do.
